// ---------------- LOGIN HANDLER (from login.html) ----------------
function loginUser(e) {
    e.preventDefault();
    alert("Login successful!");
    window.location.href = "flipkart.html"; // Redirect after login
}

// ---------------- CART FUNCTIONS (used in flipkart.html) ----------------
function addToCart(product) {
    const cart = JSON.parse(localStorage.getItem("cartItems")) || [];
    cart.push(product); // product = { name, image, price }
    localStorage.setItem("cartItems", JSON.stringify(cart));
    alert(`${product.name} added to cart.`);
}

function setupBuyButtons() {
    const buttons = document.querySelectorAll('.btn.btn-primary');
    buttons.forEach((btn) => {
        if (btn.innerText.trim() === 'Buy') {
            btn.addEventListener('click', (e) => {
                const card = e.target.closest('.card');
                const name = card.querySelector('.card-title').innerText;
                const image = card.querySelector('img').getAttribute('src');
                const price = Math.floor(Math.random() * 1000) + 500; // Simulated price
                addToCart({ name, image, price });
            });
        }
    });
}

// ---------------- CART DISPLAY (used in cart.html) ----------------
function displayCartItems() {
    const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
    const cartList = document.getElementById("cart-list");
    const totalPriceEl = document.getElementById("total-price");
    let total = 0;

    if (cartList) {
        cartList.innerHTML = "";
        cartItems.forEach((item, index) => {
            const li = document.createElement("li");
            li.innerHTML = `
                <div style="display: flex; align-items: center; gap: 15px;">
                    <img src="${item.image}" width="60" height="60" style="border-radius: 10px;">
                    <div>
                        <strong>${item.name}</strong><br>
                        ₹${item.price}
                    </div>
                    <button onclick="removeFromCart(${index})" class="btn btn-danger btn-sm">Remove</button>
                </div>
            `;
            cartList.appendChild(li);
            total += item.price;
        });
        if (totalPriceEl) totalPriceEl.innerText = `Total: ₹${total}`;
    }
}

// Remove item from cart
function removeFromCart(index) {
    const cart = JSON.parse(localStorage.getItem("cartItems")) || [];
    cart.splice(index, 1); // Remove item at index
    localStorage.setItem("cartItems", JSON.stringify(cart));
    displayCartItems(); // Re-render cart items
}

// ---------------- PAYMENT HANDLER (from payment.html) ----------------
function handlePayment(e) {
    e.preventDefault();
    alert("Payment successful!");
    localStorage.removeItem("cartItems"); // 🧹 Clear the cart after payment
    window.location.href = "delivery.html"; // ✅ Redirect to confirmation
}

// ---------------- PAYMENT NAVIGATION ----------------
function goToPayment() {
    window.location.href = "payment.html";
}

// Call setup functions when DOM is ready
document.addEventListener("DOMContentLoaded", function () {
    setupBuyButtons();
    displayCartItems();
});
